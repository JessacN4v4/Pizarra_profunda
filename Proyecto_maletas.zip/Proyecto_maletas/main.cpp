#include "maleta_base.h"
#include "maleta.h" 
#include "equipaje_especial.h"
#include "avion.h"
#include "sistema_maletas.h"

int main() {
    sistema_maletas sistema;
    sistema.mostrar_menu();
    return 0;
}